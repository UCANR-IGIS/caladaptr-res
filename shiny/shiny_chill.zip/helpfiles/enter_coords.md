### Enter Coordinates

---

You can select a location either by clicking on the map **or** manually entering longitude & latitude coordinates. If entering coordinates, enter them as decimal degrees separated by a comma. For example:

`-120.425, 37.365`

After entering coordinates, click the 'Show on Map' button to view the location.